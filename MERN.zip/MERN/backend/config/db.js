const mongoose=require('mongoose');

const connectDb=async()=>{
   try{
    await mongoose.connect(process.env.MONGO.URI)
    console.log('Database connected')
   }
   catch(e){
    console.log('database not connected')
   }
}
connectDb();