const express=require('express')
const app=express();
require('dotenv').config();
const imageRoute=require('./routes/imageRoute');
const port=process.env.PORT;
require('./config/db');
const image=require('./models/images')

app.post('/api/image',async(req,res)=>
{
    const{image_id,name,description,location,history,catagory,url}=req.body;
    const newImage=new image({
        image_id,
        name,
        description,
        location,
        history,
        catagory,
        url
    })
    await newImage.save();
    res.status(200).json({message:'image saved successfully'})
})
 
app.listen(port,()=>{
    console.log(`server is listening at port number ${port}`)
})