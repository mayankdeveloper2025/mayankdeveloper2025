const images = [
    {
        image_id: 1,
        name: 'Mountain Countryside',
        description: 'A serene view of Carpathian Mountains at sunset',
        location: 'Carpathian Mountains, Europe',
        history: 'The Carpathian Mountains are known for their rich biodiversity and cultural significance.',
        catagory: 'nature',
        url: 'https://www.mountainiq.com/wp-content/uploads/2019/02/Eastern-Carpathian-Mountains-MountainIQ.jpg?x45723'
    },
    {
        image_id: 2,
        name: 'Golden Beach',
        description: 'A breathtaking sunset on a golden sandy beach',
        location: 'Maldives, Indian Ocean',
        history: 'The Maldives is famous for its pristine beaches and vibrant coral reefs.',
        category: 'nature',
        url: 'https://th.bing.com/th/id/OIP.kTPDMZlcH26t8xiJUxqA1AHaE8?w=274&h=183&c=7&r=0&o=5&pid=1.7'
    },
    {
        image_id: 3,
        name: 'Desert Mirage',
        description: 'A vast and empty desert with a distant mirage shimmering in the heat',
        location: 'Sahara Desert, Africa',
        history: 'The Sahara Desert is the largest hot desert in the world and spans several countries.',
        category: 'nature',
        url: 'https://1.bp.blogspot.com/-TRw32AniY8Y/Ur51pa4C57I/AAAAAAAAMww/zBgkHY0TrgQ/s1600/Sand+Dunes+Of+The+Sahara+Africa_6.jpg'
    },
    {
        image_id: 4,
        name: 'City Lights',
        description: 'A stunning view of a bustling city skyline at night',
        location: 'New York City, USA',
        history: 'New York City is known as "The City that Never Sleeps" with its iconic skyline.',
        category: 'urban',
        url: 'https://wallup.net/wp-content/uploads/2017/11/17/350927-New_York_City-night-building-city_lights.jpg'
    },
    {
        image_id: 5,
        name: 'Ancient Temple',
        description: 'The ruins of an ancient temple surrounded by lush greenery',
        location: 'Angkor Wat, Cambodia',
        history: 'Angkor Wat is the largest religious monument in the world, originally constructed in the early 12th century.',
        category: 'historical',
        url: 'https://www.bortonoverseas.com/wp-content/uploads/Angkor-Wat-Main.jpg'
    },
    {
        image_id: 6,
        name: 'Snowy Peaks',
        description: 'A pristine snow-covered mountain peak under clear blue skies',
        location: 'Swiss Alps, Switzerland',
        history: 'The Swiss Alps are famous for their skiing resorts and stunning landscapes.',
        category: 'nature',
        url: 'https://rare-gallery.com/uploads/posts/986788-nature-mountains-Switzerland-Matterhorn-snowy-peak.jpg'
    },
    {
        image_id: 7,
        name: 'Cherry Blossom Garden',
        description: 'A beautiful garden filled with blooming cherry blossoms',
        location: 'Kyoto, Japan',
        history: 'Kyoto is famous for its cultural heritage and the annual cherry blossom festival.',
        category: 'nature',
        url: 'https://wallpaperaccess.com/full/89862.jpg'
    },
]