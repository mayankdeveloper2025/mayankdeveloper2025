function NotFound() {
return (
    <div>
        <h1>404 - Not Found</h1>
        <p>The page you're looking for might have been removed, had its name changed, or is temporarily unavailable.</p>
        <a href="/">Go Back Home</a>
        
    </div>
)


};

export default NotFound;